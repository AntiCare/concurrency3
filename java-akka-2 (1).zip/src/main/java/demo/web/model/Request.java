package demo.web.model;


public class Request {
    public String nameOfHotel;
    public int theAmountOfRooms;

    public Request(String nameOfHotel, int theAmountOfRooms) {
        this.nameOfHotel = nameOfHotel;
        this.theAmountOfRooms = theAmountOfRooms;
    }
}
